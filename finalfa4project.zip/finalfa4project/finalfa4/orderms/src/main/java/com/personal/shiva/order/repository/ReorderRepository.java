package com.personal.shiva.order.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.personal.shiva.order.entity.Order;
@Repository
public interface ReorderRepository extends JpaRepository<Order, String>{
	Order findByOrderid(String orderid);
}
